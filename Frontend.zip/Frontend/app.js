// app.js

document.addEventListener('DOMContentLoaded', function() {
    cargarEstudiantes();
    cargarCarreras();
    
    // Agregar evento al botón de búsqueda
    const btnBuscar = document.querySelector('.search-box .btn');
    btnBuscar.addEventListener('click', function() {
        buscarEstudiantes();
    });
    
    // Permitir búsqueda al presionar Enter en el campo de búsqueda
    const campoBusqueda = document.getElementById('buscarEstudiante');
    campoBusqueda.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault(); // Evitar envío de formulario
            buscarEstudiantes();
        }
    });
});

// Función para cargar carreras desde la API
function cargarCarreras() {
    fetch('https://localhost:44306/api/carreras')
        .then(response => response.json())
        .then(carreras => {
            const selectCarrera = document.getElementById('carrera');
            
            // Mantener la primera opción (Seleccione una carrera)
            const primeraOpcion = selectCarrera.options[0];
            selectCarrera.innerHTML = '';
            selectCarrera.appendChild(primeraOpcion);
            
            // Agregar las carreras de la API como opciones
            carreras.forEach(carrera => {
                const opcion = document.createElement('option');
                opcion.value = carrera.CarreraID;  // Usar el ID como valor
                opcion.textContent = carrera.Nombre;
                selectCarrera.appendChild(opcion);
            });
        })
        .catch(error => console.error('Error al cargar las carreras:', error));
}

function cargarEstudiantes() {
    fetch('https://localhost:44306/api/estudiantes')
        .then(response => response.json())
        .then(estudiantes => {
            mostrarEstudiantesFiltrados(estudiantes);
        })
        .catch(error => console.error('Error al cargar los estudiantes:', error));
}

// Función para realizar la búsqueda de estudiantes
function buscarEstudiantes() {
    const terminoBusqueda = document.getElementById('buscarEstudiante').value.toLowerCase().trim();
    
    // Si el término de búsqueda está vacío, mostrar todos los estudiantes
    if (terminoBusqueda === '') {
        cargarEstudiantes();
        return;
    }
    
    // Obtener todos los estudiantes y filtrarlos localmente
    fetch('https://localhost:44306/api/estudiantes')
        .then(response => response.json())
        .then(estudiantes => {
            // Filtrar estudiantes según el término de búsqueda
            const estudiantesFiltrados = estudiantes.filter(estudiante => 
                estudiante.Nombre.toLowerCase().includes(terminoBusqueda) ||
                estudiante.Apellido.toLowerCase().includes(terminoBusqueda) ||
                estudiante.Correo.toLowerCase().includes(terminoBusqueda) ||
                (estudiante.Carrera && estudiante.Carrera.Nombre.toLowerCase().includes(terminoBusqueda))
            );
            
            // Mostrar los resultados filtrados
            mostrarEstudiantesFiltrados(estudiantesFiltrados);
        })
        .catch(error => {
            console.error('Error al buscar estudiantes:', error);
            alert('Error al buscar estudiantes. Por favor, intente nuevamente.');
        });
}

// Función para mostrar los resultados filtrados en la tabla
function mostrarEstudiantesFiltrados(estudiantes) {
    const tabla = document.querySelector('#tablaEstudiantes tbody');
    tabla.innerHTML = '';  // Limpiar la tabla antes de llenarla
    
    if (estudiantes.length === 0) {
        // Si no hay resultados, mostrar mensaje
        const fila = document.createElement('tr');
        fila.innerHTML = `<td colspan="6" class="text-center">No se encontraron estudiantes que coincidan con la búsqueda</td>`;
        tabla.appendChild(fila);
        return;
    }
    
    // Llenar la tabla con los resultados filtrados
    estudiantes.forEach(estudiante => {
        const fila = document.createElement('tr');
        
        fila.innerHTML = `
            <td>${estudiante.EstudianteID}</td>
            <td>${estudiante.Nombre}</td>
            <td>${estudiante.Apellido}</td>
            <td>${estudiante.Correo}</td>
            <td>${estudiante.Carrera ? estudiante.Carrera.Nombre : 'No asignada'}</td>
            <td>
                <button class="btn btn-primary" onclick="editarEstudiante(${estudiante.EstudianteID})">Editar</button>
                <button class="btn btn-danger" onclick="eliminarEstudiante(${estudiante.EstudianteID})">Eliminar</button>
            </td>
        `;
        
        tabla.appendChild(fila);
    });
}

// Agregar el listener al formulario
document.getElementById('estudianteForm').addEventListener('submit', function(event) {
    event.preventDefault();  // Evitar el envío del formulario

    // Verificar si estamos en modo edición
    const btnFormulario = document.querySelector('#estudianteForm .btn.btn-primary');
    
    if (btnFormulario.hasAttribute('data-id')) {
        // Estamos actualizando un estudiante existente
        const estudianteID = btnFormulario.getAttribute('data-id');
        actualizarEstudiante(estudianteID);
    } else {
        // Estamos registrando un nuevo estudiante
        registrarEstudiante();
    }
});

function registrarEstudiante() {
    const nuevoEstudiante = {
        Nombre: document.getElementById('nombre').value,
        Apellido: document.getElementById('apellido').value,
        Correo: document.getElementById('correo').value,
        CarreraID: parseInt(document.getElementById('carrera').value) // Convertir a número
    };

    fetch('https://localhost:44306/api/estudiantes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(nuevoEstudiante)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        return response.json();
    })
    .then(estudiante => {
        // Limpiar el formulario y recargar la lista
        document.getElementById('estudianteForm').reset();
        cargarEstudiantes();
        alert('Estudiante registrado exitosamente');
    })
    .catch(error => {
        console.error('Error al registrar el estudiante:', error);
        alert('Error al registrar el estudiante. Por favor, intente nuevamente.');
    });
}

// Modificar la función editarEstudiante para marcar claramente el modo de edición
function editarEstudiante(estudianteID) {
    fetch(`https://localhost:44306/api/estudiantes/${estudianteID}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al obtener datos del estudiante');
            }
            return response.json();
        })
        .then(estudiante => {
            document.getElementById('nombre').value = estudiante.Nombre;
            document.getElementById('apellido').value = estudiante.Apellido;
            document.getElementById('correo').value = estudiante.Correo;
            document.getElementById('carrera').value = estudiante.CarreraID;

            // Cambiar el botón de registrar a actualizar
            const btnFormulario = document.querySelector('#estudianteForm .btn.btn-primary');
            btnFormulario.innerText = 'Actualizar Estudiante';
            btnFormulario.setAttribute('data-id', estudianteID);
            
            // Opcionalmente, hacer scroll al formulario para que el usuario vea que está en modo edición
            document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
        })
        .catch(error => {
            console.error('Error al obtener datos del estudiante:', error);
            alert('Error al obtener datos del estudiante');
        });
}

function actualizarEstudiante(estudianteID) {
    const estudianteActualizado = {
        EstudianteID: parseInt(estudianteID),
        Nombre: document.getElementById('nombre').value,
        Apellido: document.getElementById('apellido').value,
        Correo: document.getElementById('correo').value,
        CarreraID: parseInt(document.getElementById('carrera').value)
    };

    fetch(`https://localhost:44306/api/estudiantes/${estudianteID}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(estudianteActualizado)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        
        // Verificar si la respuesta contiene contenido
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            return response.json();
        } else {
            // Si no hay JSON, devolvemos un objeto vacío para continuar la cadena
            return {};
        }
    })
    .then(() => {
        // Limpiar el formulario y recargar la lista
        document.getElementById('estudianteForm').reset();
        
        // Volver a poner el texto del botón a "Registrar Estudiante"
        const btnFormulario = document.querySelector('#estudianteForm .btn.btn-primary');
        btnFormulario.innerText = 'Registrar Estudiante';
        btnFormulario.removeAttribute('data-id');
        
        cargarEstudiantes();
        alert('Estudiante actualizado exitosamente');
    })
    .catch(error => {
        console.error('Error al actualizar el estudiante:', error);
        alert('Error al actualizar el estudiante. Por favor, intente nuevamente.');
    });
}

function eliminarEstudiante(estudianteID) {
    if (confirm('¿Estás seguro de que deseas eliminar este estudiante?')) {
        fetch(`https://localhost:44306/api/estudiantes/${estudianteID}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al eliminar el estudiante');
            }
            cargarEstudiantes();  // Recargar la lista de estudiantes
            alert('Estudiante eliminado exitosamente');
        })
        .catch(error => {
            console.error('Error al eliminar el estudiante:', error);
            alert('Error al eliminar el estudiante. Por favor, intente nuevamente.');
        });
    }
}