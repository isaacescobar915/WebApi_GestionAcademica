// cursos.js - Código específico para la gestión de cursos

document.addEventListener('DOMContentLoaded', function() {
    cargarCursos();
    
    // Agregar evento al botón de búsqueda
    const btnBuscar = document.querySelector('.search-box .btn');
    btnBuscar.addEventListener('click', function() {
        buscarCursos();
    });
    
    // Permitir búsqueda al presionar Enter en el campo de búsqueda
    const campoBusqueda = document.getElementById('buscarCurso');
    campoBusqueda.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault(); // Evitar envío de formulario
            buscarCursos();
        }
    });

    // Agregar el listener al formulario de cursos
    document.getElementById('cursoForm').addEventListener('submit', function(event) {
        event.preventDefault();  // Evitar el envío del formulario

        // Verificar si estamos en modo edición
        const btnFormulario = document.querySelector('#cursoForm .btn.btn-primary');
        
        if (btnFormulario.hasAttribute('data-id')) {
            // Estamos actualizando un curso existente
            const cursoID = btnFormulario.getAttribute('data-id');
            actualizarCurso(cursoID);
        } else {
            // Estamos registrando un nuevo curso
            registrarCurso();
        }
    });
});

function cargarCursos() {
    fetch('https://localhost:44306/api/cursos')
        .then(response => response.json())
        .then(cursos => {
            mostrarCursosFiltrados(cursos);
        })
        .catch(error => console.error('Error al cargar los cursos:', error));
}

// Función para realizar la búsqueda de cursos
function buscarCursos() {
    const terminoBusqueda = document.getElementById('buscarCurso').value.toLowerCase().trim();
    
    // Si el término de búsqueda está vacío, mostrar todos los cursos
    if (terminoBusqueda === '') {
        cargarCursos();
        return;
    }
    
    // Obtener todos los cursos y filtrarlos localmente
    fetch('https://localhost:44306/api/cursos')
        .then(response => response.json())
        .then(cursos => {
            // Filtrar cursos según el término de búsqueda
            const cursosFiltrados = cursos.filter(curso => 
                curso.Codigo.toLowerCase().includes(terminoBusqueda) ||
                curso.Nombre.toLowerCase().includes(terminoBusqueda) ||
                curso.Descripcion.toLowerCase().includes(terminoBusqueda)
            );
            
            // Mostrar los resultados filtrados
            mostrarCursosFiltrados(cursosFiltrados);
        })
        .catch(error => {
            console.error('Error al buscar cursos:', error);
            alert('Error al buscar cursos. Por favor, intente nuevamente.');
        });
}

// Función para mostrar los resultados filtrados en la tabla
function mostrarCursosFiltrados(cursos) {
    const tabla = document.querySelector('#tablaCursos tbody');
    tabla.innerHTML = '';  // Limpiar la tabla antes de llenarla
    
    if (cursos.length === 0) {
        // Si no hay resultados, mostrar mensaje
        const fila = document.createElement('tr');
        fila.innerHTML = `<td colspan="4" class="text-center">No se encontraron cursos que coincidan con la búsqueda</td>`;
        tabla.appendChild(fila);
        return;
    }
    
    // Llenar la tabla con los resultados filtrados
    cursos.forEach(curso => {
        const fila = document.createElement('tr');
        
        fila.innerHTML = `
            <td>${curso.Codigo}</td>
            <td>${curso.Nombre}</td>
            <td>${curso.Descripcion}</td>
            <td>
                <button class="btn btn-primary" onclick="editarCurso(${curso.CursoID})">Editar</button>
                <button class="btn btn-danger" onclick="eliminarCurso(${curso.CursoID})">Eliminar</button>
            </td>
        `;
        
        tabla.appendChild(fila);
    });
}

function registrarCurso() {
    const nuevoCurso = {
        Codigo: document.getElementById('codigoCurso').value,
        Nombre: document.getElementById('nombreCurso').value,
        Descripcion: document.getElementById('descripcionCurso').value
    };

    fetch('https://localhost:44306/api/cursos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(nuevoCurso)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        return response.json();
    })
    .then(curso => {
        // Limpiar el formulario y recargar la lista
        document.getElementById('cursoForm').reset();
        cargarCursos();
        alert('Curso registrado exitosamente');
    })
    .catch(error => {
        console.error('Error al registrar el curso:', error);
        alert('Error al registrar el curso. Por favor, intente nuevamente.');
    });
}

function editarCurso(cursoID) {
    fetch(`https://localhost:44306/api/cursos/${cursoID}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al obtener datos del curso');
            }
            return response.json();
        })
        .then(curso => {
            document.getElementById('codigoCurso').value = curso.Codigo;
            document.getElementById('nombreCurso').value = curso.Nombre;
            document.getElementById('descripcionCurso').value = curso.Descripcion;

            // Cambiar el botón de registrar a actualizar
            const btnFormulario = document.querySelector('#cursoForm .btn.btn-primary');
            btnFormulario.innerText = 'Actualizar Curso';
            btnFormulario.setAttribute('data-id', cursoID);
            
            // Opcionalmente, hacer scroll al formulario para que el usuario vea que está en modo edición
            document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
        })
        .catch(error => {
            console.error('Error al obtener datos del curso:', error);
            alert('Error al obtener datos del curso');
        });
}

function actualizarCurso(cursoID) {
    const cursoActualizado = {
        CursoID: parseInt(cursoID),
        Codigo: document.getElementById('codigoCurso').value,
        Nombre: document.getElementById('nombreCurso').value,
        Descripcion: document.getElementById('descripcionCurso').value
    };

    fetch(`https://localhost:44306/api/cursos/${cursoID}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(cursoActualizado)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        
        // Verificar si la respuesta contiene contenido
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            return response.json();
        } else {
            // Si no hay JSON, devolvemos un objeto vacío para continuar la cadena
            return {};
        }
    })
    .then(() => {
        // Limpiar el formulario y recargar la lista
        document.getElementById('cursoForm').reset();
        
        // Volver a poner el texto del botón a "Registrar Curso"
        const btnFormulario = document.querySelector('#cursoForm .btn.btn-primary');
        btnFormulario.innerText = 'Registrar Curso';
        btnFormulario.removeAttribute('data-id');
        
        cargarCursos();
        alert('Curso actualizado exitosamente');
    })
    .catch(error => {
        console.error('Error al actualizar el curso:', error);
        alert('Error al actualizar el curso. Por favor, intente nuevamente.');
    });
}

function eliminarCurso(cursoID) {
    if (confirm('¿Estás seguro de que deseas eliminar este curso?')) {
        fetch(`https://localhost:44306/api/cursos/${cursoID}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al eliminar el curso');
            }
            cargarCursos();  // Recargar la lista de cursos
            alert('Curso eliminado exitosamente');
        })
        .catch(error => {
            console.error('Error al eliminar el curso:', error);
            alert('Error al eliminar el curso. Por favor, intente nuevamente.');
        });
    }
}