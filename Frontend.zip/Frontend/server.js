// server.js
const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Configurar CORS - Esto permite que el servidor Node.js acepte solicitudes de cualquier origen
app.use(cors());

// Servir archivos estáticos desde la carpeta actual
app.use(express.static(path.join(__dirname)));

// Configurar proxy para redirigir las solicitudes a la API
app.use('/api', createProxyMiddleware({
    target: 'https://localhost:44306', // Tu API backend ASP.NET
    changeOrigin: true, // Cambia el origen de la solicitud al del servidor destino
    secure: false, // Permite certificados SSL autofirmados
    onProxyReq: (proxyReq, req, res) => {
      // Añadir cabeceras a la solicitud que se envía al backend
      proxyReq.setHeader('X-Forwarded-Proto', 'https');
    },
    onProxyRes: (proxyRes, req, res) => {
      // Añadir cabeceras CORS a las respuestas que vienen del backend
      proxyRes.headers['Access-Control-Allow-Origin'] = '*';
      proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
      proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
      proxyRes.headers['Access-Control-Allow-Credentials'] = 'true';
    }
}));

// Ruta principal que sirve el archivo index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});