// Variables globales
let carreras = [];
let estudiantes = [];
let cursos = [];
let asignaciones = [];
let asignacionEditando = null;

// Función para inicializar el módulo de asignaciones
function inicializarModuloAsignaciones() {
    // Cargar datos iniciales
    cargarCarreras();
    cargarCursos();
    cargarAsignaciones();
    
    // Configurar event listeners
    document.getElementById('carreraFiltro').addEventListener('change', filtrarEstudiantesPorCarrera);
    document.getElementById('asignacionForm').addEventListener('submit', guardarAsignacion);
    document.getElementById('btnBuscarAsignacion').addEventListener('click', buscarAsignaciones);
    document.getElementById('btnBuscarEstudianteGlobal').addEventListener('click', buscarEstudianteGlobal);
    document.getElementById('btnCancelarEdicion').addEventListener('click', cancelarEdicionAsignacion);
    
    // Configurar búsqueda por tecla enter
    document.getElementById('buscarAsignacion').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            buscarAsignaciones();
        }
    });
    
    document.getElementById('buscarEstudianteGlobal').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            buscarEstudianteGlobal();
        }
    });
}

// Cargar carreras desde la API
async function cargarCarreras() {
    try {
        const response = await fetch('https://localhost:44306/api/carreras');
        if (!response.ok) {
            throw new Error('Error al cargar carreras');
        }
        
        carreras = await response.json();
        
        // Llenar select de carreras
        const carreraSelect = document.getElementById('carreraFiltro');
        carreraSelect.innerHTML = '<option value="">Seleccione una carrera</option>';
        
        carreras.forEach(carrera => {
            const option = document.createElement('option');
            option.value = carrera.CarreraID;
            option.textContent = carrera.Nombre;
            carreraSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error al cargar carreras:', error);
        mostrarAlerta('Error al cargar carreras: ' + error.message, 'error');
    }
}

// Cargar estudiantes filtrados por carrera
async function filtrarEstudiantesPorCarrera() {
    const carreraId = document.getElementById('carreraFiltro').value;
    const estudianteSelect = document.getElementById('estudianteAsignacion');
    
    estudianteSelect.innerHTML = '<option value="">Seleccione un estudiante</option>';
    
    if (!carreraId) {
        estudianteSelect.disabled = true;
        return;
    }
    
    try {
        const response = await fetch('https://localhost:44306/api/estudiantes');
        if (!response.ok) {
            throw new Error('Error al cargar estudiantes');
        }
        
        estudiantes = await response.json();
        const estudiantesFiltrados = estudiantes.filter(est => est.CarreraID == carreraId);
        
        estudiantesFiltrados.forEach(estudiante => {
            const option = document.createElement('option');
            option.value = estudiante.EstudianteID;
            option.textContent = `${estudiante.Nombre} ${estudiante.Apellido}`;
            estudianteSelect.appendChild(option);
        });
        
        estudianteSelect.disabled = false;
    } catch (error) {
        console.error('Error al cargar estudiantes:', error);
        mostrarAlerta('Error al cargar estudiantes: ' + error.message, 'error');
    }
}

// Cargar cursos desde la API
async function cargarCursos() {
    try {
        const response = await fetch('https://localhost:44306/api/cursos');
        if (!response.ok) {
            throw new Error('Error al cargar cursos');
        }
        
        cursos = await response.json();
        
        // Llenar select de cursos
        const cursoSelect = document.getElementById('cursoAsignacion');
        cursoSelect.innerHTML = '<option value="">Seleccione un curso</option>';
        
        cursos.forEach(curso => {
            const option = document.createElement('option');
            option.value = curso.CursoID;
            option.textContent = `${curso.Codigo} - ${curso.Nombre}`;
            cursoSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error al cargar cursos:', error);
        mostrarAlerta('Error al cargar cursos: ' + error.message, 'error');
    }
}

// Cargar asignaciones desde la API
async function cargarAsignaciones() {
    try {
        const response = await fetch('https://localhost:44306/api/asignaciones');
        if (!response.ok) {
            throw new Error('Error al cargar asignaciones');
        }
        
        asignaciones = await response.json();
        mostrarAsignaciones(asignaciones);
    } catch (error) {
        console.error('Error al cargar asignaciones:', error);
        mostrarAlerta('Error al cargar asignaciones: ' + error.message, 'error');
    }
}

// Mostrar asignaciones en la tabla
function mostrarAsignaciones(listaAsignaciones) {
    const tabla = document.getElementById('tablaAsignaciones').getElementsByTagName('tbody')[0];
    tabla.innerHTML = '';
    
    if (listaAsignaciones.length === 0) {
        const fila = tabla.insertRow();
        const celda = fila.insertCell(0);
        celda.colSpan = 5;
        celda.textContent = 'No se encontraron asignaciones';
        return;
    }
    
    listaAsignaciones.forEach(asignacion => {
        const fila = tabla.insertRow();
        
        const celdaId = fila.insertCell(0);
        celdaId.textContent = asignacion.AsignacionID;
        
        const celdaEstudiante = fila.insertCell(1);
        celdaEstudiante.textContent = `${asignacion.Estudiante.Nombre} ${asignacion.Estudiante.Apellido}`;
        
        const celdaCarrera = fila.insertCell(2);
        celdaCarrera.textContent = asignacion.Estudiante.Carrera.Nombre;
        
        const celdaCurso = fila.insertCell(3);
        celdaCurso.textContent = `${asignacion.Curso.Codigo} - ${asignacion.Curso.Nombre}`;
        
        const celdaAcciones = fila.insertCell(4);
        celdaAcciones.innerHTML = `
            <button class="btn btn-sm btn-warning editar-asignacion" data-id="${asignacion.AsignacionID}">Editar</button>
            <button class="btn btn-sm btn-danger eliminar-asignacion" data-id="${asignacion.AsignacionID}">Eliminar</button>
        `;
    });
    
    // Agregar listeners a los botones de acciones
    document.querySelectorAll('.editar-asignacion').forEach(btn => {
        btn.addEventListener('click', function() {
            editarAsignacion(this.getAttribute('data-id'));
        });
    });
    
    document.querySelectorAll('.eliminar-asignacion').forEach(btn => {
        btn.addEventListener('click', function() {
            eliminarAsignacion(this.getAttribute('data-id'));
        });
    });
}

// Guardar o actualizar asignación
async function guardarAsignacion(e) {
    e.preventDefault();
    
    const estudianteId = document.getElementById('estudianteAsignacion').value;
    const cursoId = document.getElementById('cursoAsignacion').value;
    const asignacionId = document.getElementById('asignacionIdEditar').value;
    
    if (!estudianteId || !cursoId) {
        mostrarAlerta('Por favor, complete todos los campos', 'warning');
        return;
    }
    
    const asignacionData = {
        EstudianteID: parseInt(estudianteId),
        CursoID: parseInt(cursoId)
    };
    
    try {
        if (asignacionId) {
            // Para edición, primero eliminamos la asignación existente
            await eliminarAsignacion(asignacionId, false);
            // Luego creamos una nueva
            mostrarAlerta('Actualizando asignación...', 'info');
        }
        
        // Siempre usamos POST porque no hay PUT disponible
        const response = await fetch('https://localhost:44306/api/asignaciones', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(asignacionData)
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Error al guardar la asignación: ${errorText}`);
        }
        
        await cargarAsignaciones();
        resetearFormulario();
        mostrarAlerta(asignacionId ? 'Asignación actualizada correctamente' : 'Asignación creada correctamente', 'success');
    } catch (error) {
        console.error('Error al guardar la asignación:', error);
        mostrarAlerta('Error al guardar la asignación: ' + error.message, 'error');
    }
}

// Buscar asignaciones
function buscarAsignaciones() {
    const textoBusqueda = document.getElementById('buscarAsignacion').value.toLowerCase();
    
    if (!textoBusqueda) {
        mostrarAsignaciones(asignaciones);
        return;
    }
    
    const asignacionesFiltradas = asignaciones.filter(asignacion => {
        const nombreCompleto = `${asignacion.Estudiante.Nombre} ${asignacion.Estudiante.Apellido}`.toLowerCase();
        const nombreCurso = asignacion.Curso.Nombre.toLowerCase();
        const codigoCurso = asignacion.Curso.Codigo.toLowerCase();
        const nombreCarrera = asignacion.Estudiante.Carrera.Nombre.toLowerCase();
        
        return nombreCompleto.includes(textoBusqueda) || 
               nombreCurso.includes(textoBusqueda) || 
               codigoCurso.includes(textoBusqueda) ||
               nombreCarrera.includes(textoBusqueda);
    });
    
    mostrarAsignaciones(asignacionesFiltradas);
}

// Buscar estudiante global
async function buscarEstudianteGlobal() {
    const textoBusqueda = document.getElementById('buscarEstudianteGlobal').value.toLowerCase();
    
    if (!textoBusqueda) {
        mostrarAlerta('Ingrese un texto para buscar', 'warning');
        return;
    }
    
    try {
        if (estudiantes.length === 0) {
            const response = await fetch('https://localhost:44306/api/estudiantes');
            if (!response.ok) {
                throw new Error('Error al cargar estudiantes');
            }
            estudiantes = await response.json();
        }
        
        const estudianteEncontrado = estudiantes.find(est => {
            const nombreCompleto = `${est.Nombre} ${est.Apellido}`.toLowerCase();
            return nombreCompleto.includes(textoBusqueda);
        });
        
        if (estudianteEncontrado) {
            // Seleccionar la carrera del estudiante
            document.getElementById('carreraFiltro').value = estudianteEncontrado.CarreraID;
            
            // Cargar los estudiantes de esa carrera
            await filtrarEstudiantesPorCarrera();
            
            // Seleccionar el estudiante
            document.getElementById('estudianteAsignacion').value = estudianteEncontrado.EstudianteID;
            
            mostrarAlerta('Estudiante encontrado', 'success');
        } else {
            mostrarAlerta('No se encontró ningún estudiante con ese nombre', 'warning');
        }
    } catch (error) {
        console.error('Error al buscar estudiante:', error);
        mostrarAlerta('Error al buscar estudiante: ' + error.message, 'error');
    }
}

// Editar asignación
async function editarAsignacion(id) {
    const asignacion = asignaciones.find(a => a.AsignacionID == id);
    
    if (!asignacion) {
        mostrarAlerta('No se encontró la asignación', 'error');
        return;
    }
    
    // Guardar asignación que estamos editando
    asignacionEditando = asignacion;
    
    // Seleccionar la carrera del estudiante
    document.getElementById('carreraFiltro').value = asignacion.Estudiante.CarreraID;
    
    // Cargar los estudiantes de esa carrera y luego seleccionar el estudiante
    await filtrarEstudiantesPorCarrera();
    document.getElementById('estudianteAsignacion').value = asignacion.EstudianteID;
    document.getElementById('cursoAsignacion').value = asignacion.CursoID;
    document.getElementById('asignacionIdEditar').value = asignacion.AsignacionID;
    
    // Cambiar texto del botón y mostrar botón cancelar
    document.getElementById('btnGuardarAsignacion').textContent = 'Actualizar Asignación';
    document.getElementById('btnCancelarEdicion').style.display = 'inline-block';
}

// Eliminar asignación
async function eliminarAsignacion(id, confirmar = true) {
    if (confirmar && !confirm('¿Está seguro de eliminar esta asignación?')) {
        return;
    }
    
    try {
        const response = await fetch(`https://localhost:44306/api/asignaciones/${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Error al eliminar la asignación: ${errorText}`);
        }
        
        if (confirmar) {
            await cargarAsignaciones();
            mostrarAlerta('Asignación eliminada correctamente', 'success');
        }
        return true;
    } catch (error) {
        console.error('Error al eliminar la asignación:', error);
        if (confirmar) {
            mostrarAlerta('Error al eliminar la asignación: ' + error.message, 'error');
        }
        throw error;
    }
}

// Cancelar edición
function cancelarEdicionAsignacion() {
    resetearFormulario();
}

// Resetear formulario
function resetearFormulario() {
    document.getElementById('asignacionForm').reset();
    document.getElementById('estudianteAsignacion').disabled = true;
    document.getElementById('asignacionIdEditar').value = '';
    document.getElementById('btnGuardarAsignacion').textContent = 'Asignar Estudiante al Curso';
    document.getElementById('btnCancelarEdicion').style.display = 'none';
    asignacionEditando = null;
}

// Mostrar alerta
function mostrarAlerta(mensaje, tipo) {
    console.log(`[${tipo}] ${mensaje}`);
    alert(mensaje);
}

document.addEventListener('DOMContentLoaded', inicializarModuloAsignaciones);